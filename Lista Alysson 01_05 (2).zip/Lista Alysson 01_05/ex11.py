#11- Faça um algoritmo que receba o preço de custo e o preço de venda de 40 produtos. Mostre como resultado se houve lucro, prejuízo ou empate para cada produto. Informe a média de preço de custo e do preço de venda.

total_produtos = 40
soma_preco_custo = 0
soma_preco_venda = 0

for i in range(total_produtos):
    preco_custo = float(input("Digite o preço de custo do produto {}: ".format(i + 1)))
    preco_venda = float(input("Digite o preço de venda do produto {}: ".format(i + 1)))

    soma_preco_custo += preco_custo
    soma_preco_venda += preco_venda

    if preco_venda > preco_custo:
        print("Produto {}: Lucro".format(i + 1))
    elif preco_venda < preco_custo:
        print("Produto {}: Prejuízo".format(i + 1))
    else:
        print("Produto {}: Empate".format(i + 1))

media_preco_custo = soma_preco_custo / total_produtos
media_preco_venda = soma_preco_venda / total_produtos

print("\nMédia de preço de custo: {:.2f}".format(media_preco_custo))
print("Média de preço de venda: {:.2f}".format(media_preco_venda))
