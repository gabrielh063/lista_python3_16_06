#4- Faça um programa, utilizando while, que mostre na tela os números de 0 a 100.

a = 0

while a <= 100:
    print(a)
    a+=1