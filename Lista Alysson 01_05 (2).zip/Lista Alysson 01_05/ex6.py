#6- Escrever um algoritmo que lê o número de identificação, as 3 notas obtidas por um aluno nas 3 verificações e a média dos exercícios que fazem parte da avaliação. Calcular a média de aproveitamento, usando a fórmula:
#MA = (Nota1 + Nota2 x 2 + Nota3 x 3 + ME )/7
#A atribuição de conceitos obedece a tabela abaixo:

#Média de Aproveitamento | Conceito
#MA >= 9,0               | A
#7,5 <= MA < 9,0         | B
#6,0 <= MA < 7,5         | C
#4,0 <= MA < 6,0         | D
#MA < 4,0                | E

numero_identificacao = int(input("Digite o número de identificação do aluno: "))
nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))
media_exercicios = float(input("Digite a média dos exercícios: "))

media_aproveitamento = (nota1 + nota2 * 2 + nota3 * 3 + media_exercicios) / 7

if media_aproveitamento >= 9.0:
    conceito = "A"
elif 7.5 <= media_aproveitamento < 9.0:
    conceito = "B"
elif 6.0 <= media_aproveitamento < 7.5:
    conceito = "C"
elif 4.0 <= media_aproveitamento < 6.0:
    conceito = "D"
else:
    conceito = "E"

print("Média de Aproveitamento:", media_aproveitamento)
print("Conceito:", conceito)
