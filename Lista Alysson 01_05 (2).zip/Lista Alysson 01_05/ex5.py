#5- Faça um programa que calcule e mostre a média aritmética de N notas. N equivale ao total de avaliações. 

n = int(input("Digite o total de avaliações: "))
soma = 0

for i in range(n):
    nota = float(input(f"Digite a nota {i+1}: "))
    soma += nota

media = soma / n
print(f"A média aritmética das {n} notas é: {media:.2f}")