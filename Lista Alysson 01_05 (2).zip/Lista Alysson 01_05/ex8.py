#8- Faça um algoritmo que receba a idade de 75 pessoas e mostre mensagem informando “maior de idade” e “menor de idade” para cada pessoa. Considere a idade a partir de 18 anos como maior de idade.

qnt =int(input('Quantas Pessoas Há?: '))
for a in range(qnt):
    idade = int(input('Qual a sua Idade?: '))
    if idade <=18:
        print('Menor de Idade')
    elif idade >=18:
        print('Maior de Idade')
    else:
        print('Idade Invalida')