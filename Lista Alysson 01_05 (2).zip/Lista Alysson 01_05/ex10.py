#10 Faça um algoritmo que receba “N” números e mostre positivo, negativo ou zero para cada número

n = int(input("Digite a quantidade de números: "))

for i in range(n):
    numero = float(input("Digite um número: "))

    if numero > 0:
        print("Positivo")
    elif numero < 0:
        print("Negativo")
    else:
        print("Zero")
