#2- Faça um programa que leia um nome de usuário e a sua senha e não aceite a senha igual ao nome do usuário, mostrando uma mensagem de erro e voltando a pedir as informações.

user = input('Digite o seu Usuário: ')
senha = input('Digite a sua Senha: ')

while senha == user: 
    print('Não é permitido a senha igual ao nome de usuário')
    senha = input('Digite a sua Senha: ')

print('Obrigado por se registrar :) ')