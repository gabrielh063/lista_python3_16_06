#7- Ler 80 números e ao final informar quantos número(s) est(á)ão no intervalo entre 10 (inclusive) e 150 (inclusive).

for a in range(10,151):
    print(a)
    
print(f'Há {a - 1} números no intervalo')
